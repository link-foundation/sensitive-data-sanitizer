import { StrictMode, createElement as h } from 'react';
import { createRoot } from 'react-dom/client';
import { App } from './App.js';
import './styles.css';

createRoot(document.getElementById('root')).render(h(StrictMode, null, h(App)));
